package dao;

import static db.JdbcUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import vo.campaign.CampaignHistoryBean;
import vo.donation.DonationBankBean;
import vo.donation.DonationBean;
import vo.donation.DonationCardBean;

public class DonationDAO {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";
	
	private static DonationDAO donationDAO;
	
	public static DonationDAO getInstance() {
		if (donationDAO == null) {
			donationDAO = new DonationDAO();
		}
		return donationDAO;
	}
	
	public void setConnection(Connection con) {
		this.con = con;
	}

	//일반회원 카드 기부 처리
	public int donationCardNormalMember(DonationBean donationInfo) {
		int donationCount = 0;
		try {
			sql = "insert into normalMember_donation_tbl(donation_member_id, donation_money, donation_date, donation_campaign_no, donation_type, pay_type, pay_status) values (?, ?, now(), ?, ?, ?, 'Y')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, donationInfo.getDonation_member_id());
			pstmt.setString(2, donationInfo.getDonation_money());
			pstmt.setInt(3, donationInfo.getDonation_campaign_no());
			pstmt.setString(4, donationInfo.getDonation_type());
			pstmt.setString(5, donationInfo.getPay_type());
			
			donationCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationCardNormalMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return donationCount;
	}

	//기업/단체회원 카드 기부 처리
	public int donationCardComgrpMember(DonationBean donationInfo) {
		int donationCount = 0;
		try {
			sql = "insert into comgrpMember_donation_tbl(donation_member_id, donation_money, donation_date, donation_campaign_no, donation_type, pay_type, pay_status) values (?, ?, now(), ?, ?, ?, 'Y')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, donationInfo.getDonation_member_id());
			pstmt.setString(2, donationInfo.getDonation_money());
			pstmt.setInt(3, donationInfo.getDonation_campaign_no());
			pstmt.setString(4, donationInfo.getDonation_type());
			pstmt.setString(5, donationInfo.getPay_type());
			
			donationCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationCardComgrpMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return donationCount;
	}

	//일반회원 계좌 기부 처리
	public int donationBankNormalMember(DonationBean donationInfo) {
		int donationCount = 0;
		try {
			sql = "insert into normalMember_donation_tbl(donation_member_id, donation_money, donation_date, donation_campaign_no, donation_type, pay_type, pay_status) values (?, ?, now(), ?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, donationInfo.getDonation_member_id());
			pstmt.setString(2, donationInfo.getDonation_money());
			pstmt.setInt(3, donationInfo.getDonation_campaign_no());
			pstmt.setString(4, donationInfo.getDonation_type());
			pstmt.setString(5, donationInfo.getPay_type());
			
			donationCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationBankNormalMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return donationCount;
	}

	//기업/단체회원 계좌 기부 처리
	public int donationBankComgrpMember(DonationBean donationInfo) {
		int donationCount = 0;
		try {
			sql = "insert into comgrpMember_donation_tbl(donation_member_id, donation_money, donation_date, donation_campaign_no, donation_type, pay_type, pay_status) values (?, ?, now(), ?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, donationInfo.getDonation_member_id());
			pstmt.setString(2, donationInfo.getDonation_money());
			pstmt.setInt(3, donationInfo.getDonation_campaign_no());
			pstmt.setString(4, donationInfo.getDonation_type());
			pstmt.setString(5, donationInfo.getPay_type());
			
			donationCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationBankComgrpMember 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return donationCount;
	}
	
	//일반회원 기부번호 가져오기
	public int getNormalMemberDonationNo() {
		int donation_no = 0;
		try {
			sql = "select max(donation_no) as donation_no from normalMember_donation_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				donation_no = rs.getInt("donation_no");
			}
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationNo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return donation_no;
	}
	
	//기업/단체회원 기부번호 가져오기
	public int getComgrpMemberDonationNo() {
		int donation_no = 0;
		try {
			sql = "select max(donation_no) as donation_no from comgrpMember_donation_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				donation_no = rs.getInt("donation_no");
			}
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationNo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return donation_no;
	}

	//일반회원 카드 일시결제 정보 Insert
	public int donationNormalMemberTemporaryCardInfoInsert(DonationCardBean cardInfo) {
		int cardInfoInsertCount = 0;
		try {
			sql = "insert into normalMember_donation_cardInfo_tbl values (?, ?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, cardInfo.getDonation_no());
			pstmt.setString(2, cardInfo.getCard_category());
			pstmt.setString(3, cardInfo.getCard_proprietor());
			pstmt.setString(4, cardInfo.getCard_name());
			
			cardInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationNormalMemberTemporaryCardInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return cardInfoInsertCount;
	}

	//일반회원 카드 정기결제 정보 Insert
	public int donationNormalMemberRegularlyCardInfoInsert(DonationCardBean cardInfo) {
		int cardInfoInsertCount = 0;
		try {
			sql = "insert into normalMember_donation_cardInfo_tbl values (?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, cardInfo.getDonation_no());
			pstmt.setString(2, cardInfo.getCard_category());
			pstmt.setString(3, cardInfo.getCard_proprietor());
			pstmt.setString(4, cardInfo.getCard_name());
			pstmt.setString(5, cardInfo.getPay_date());
			
			cardInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationNormalMemberRegularlyCardInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return cardInfoInsertCount;
	}

	//기업/단체회원 카드 일시결제 정보 Insert
	public int donationComgrpMemberTemporaryCardInfoInsert(DonationCardBean cardInfo) {
		int cardInfoInsertCount = 0;
		try {
			sql = "insert into comgrpMember_donation_cardInfo_tbl values (?, ?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, cardInfo.getDonation_no());
			pstmt.setString(2, cardInfo.getCard_category());
			pstmt.setString(3, cardInfo.getCard_proprietor());
			pstmt.setString(4, cardInfo.getCard_name());
			
			cardInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationComgrpMemberTemporaryCardInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return cardInfoInsertCount;
	}

	//기업/단체회원 카드 정기결제 정보 Insert
	public int donationComgrpMemberRegularlyCardInfoInsert(DonationCardBean cardInfo) {
		int cardInfoInsertCount = 0;
		try {
			sql = "insert into comgrpMember_donation_cardInfo_tbl values (?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, cardInfo.getDonation_no());
			pstmt.setString(2, cardInfo.getCard_category());
			pstmt.setString(3, cardInfo.getCard_proprietor());
			pstmt.setString(4, cardInfo.getCard_name());
			pstmt.setString(5, cardInfo.getPay_date());
			
			cardInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationComgrpMemberRegularlyCardInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return cardInfoInsertCount;
	}

	//일반회원 계좌 일시결제 정보 Insert
	public int donationNormalMemberTemporaryBankInfoInsert(DonationBankBean bankInfo) {
		int bankInfoInsertCount = 0;
		try {
			sql = "insert into normalMember_donation_bankInfo_tbl values (?, ?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, bankInfo.getDonation_no());
			pstmt.setString(2, bankInfo.getBank_category());
			pstmt.setString(3, bankInfo.getBank_proprietor());
			pstmt.setString(4, bankInfo.getBank_name());
			
			bankInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationNormalMemberTemporaryBankInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return bankInfoInsertCount;
	}

	//일반회원 계좌 정기결제 정보 Insert
	public int donationNormalMemberRegularlyBankInfoInsert(DonationBankBean bankInfo) {
		int bankInfoInsertCount = 0;
		try {
			sql = "insert into normalMember_donation_bankInfo_tbl values (?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, bankInfo.getDonation_no());
			pstmt.setString(2, bankInfo.getBank_category());
			pstmt.setString(3, bankInfo.getBank_proprietor());
			pstmt.setString(4, bankInfo.getBank_name());
			pstmt.setString(5, bankInfo.getPay_date());
			
			bankInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationNormalMemberRegularlyBankInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return bankInfoInsertCount;
	}

	//기업/단체회원 계좌 일시결제 정보 Insert
	public int donationComgrpMemberTemporaryBankInfoInsert(DonationBankBean bankInfo) {
		int bankInfoInsertCount = 0;
		try {
			sql = "insert into comgrpMember_donation_bankInfo_tbl values (?, ?, ?, ?, 'N')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, bankInfo.getDonation_no());
			pstmt.setString(2, bankInfo.getBank_category());
			pstmt.setString(3, bankInfo.getBank_proprietor());
			pstmt.setString(4, bankInfo.getBank_name());
			
			bankInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationComgrpMemberTemporaryBankInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return bankInfoInsertCount;
	}

	//기업/단체회원 계좌 정기결제 정보 Insert
	public int donationComgrpMemberRegularlyBankInfoInsert(DonationBankBean bankInfo) {
		int bankInfoInsertCount = 0;
		try {
			sql = "insert into comgrpMember_donation_bankInfo_tbl values (?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, bankInfo.getDonation_no());
			pstmt.setString(2, bankInfo.getBank_category());
			pstmt.setString(3, bankInfo.getBank_proprietor());
			pstmt.setString(4, bankInfo.getBank_name());
			pstmt.setString(5, bankInfo.getPay_date());
			
			bankInfoInsertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("donationComgrpMemberRegularlyBankInfoInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return bankInfoInsertCount;
	}

	//일반회원 기부내역 가져오기
	public ArrayList<DonationBean> getNormalMemberDonationInfo() {
		ArrayList<DonationBean> normalDonationInfo = new ArrayList<DonationBean>();
		try {
			sql = "select donation_campaign_no, donation_member_id, format(sum(donation_money),0) as donation_money from normalMember_donation_tbl where pay_status = 'Y' group by donation_member_id, donation_campaign_no";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationBean normalDonationInfoBean = null;
			
			while (rs.next()) {
				normalDonationInfoBean = new DonationBean();
				
				normalDonationInfoBean.setDonation_campaign_no(rs.getInt("donation_campaign_no"));
				normalDonationInfoBean.setDonation_member_id(rs.getString("donation_member_id"));
				normalDonationInfoBean.setDonation_money(rs.getString("donation_money"));
				
				normalDonationInfo.add(normalDonationInfoBean);
			}
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return normalDonationInfo;
	}

	//기업/단체회원 기부내역 가져오기
	public ArrayList<DonationBean> getComgrpMemberDonationInfo() {
		ArrayList<DonationBean> comgrpDonationInfo = new ArrayList<DonationBean>();
		try {
			sql = "select donation_campaign_no, donation_member_id, format(sum(donation_money),0) as donation_money from comgrpMember_donation_tbl where pay_status = 'Y' group by donation_member_id, donation_campaign_no";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationBean comgrpDonationInfoBean = null;
			
			while (rs.next()) {
				comgrpDonationInfoBean = new DonationBean();
				
				comgrpDonationInfoBean.setDonation_campaign_no(rs.getInt("donation_campaign_no"));
				comgrpDonationInfoBean.setDonation_member_id(rs.getString("donation_member_id"));
				comgrpDonationInfoBean.setDonation_money(rs.getString("donation_money"));
				
				comgrpDonationInfo.add(comgrpDonationInfoBean);
			}
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return comgrpDonationInfo;
	}

	//나의 캠페인 별 총 후원금 가져오기
	public String getMyDonationMoney(String id, int campaign_no) {
		String money = "";
		try {
			sql = "select format(sum(donation_money),0) as donation_money from normalMember_donation_tbl where donation_campaign_no = "+ campaign_no +" and pay_status = 'Y' and donation_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				if (rs.getString("donation_money") != null) {
					money = rs.getString("donation_money");
				} else {
					sql = "select format(sum(donation_money),0) as donation_money from comgrpMember_donation_tbl where donation_campaign_no = "+ campaign_no +" and pay_status = 'Y' and donation_member_id = '" + id + "'";
					pstmt = con.prepareStatement(sql);
					rs = pstmt.executeQuery();
				
					if (rs.next()) {
						if (rs.getString("donation_money") != null) {
							money = rs.getString("donation_money");
						} else {
							money = "0";
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println("getMyDonationMoney 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return money;
	}

	//관리자 단체회원 지원단체 신청 승인 전 신청단체 가져오기
	public ArrayList<DonationBean> getSupportGroupApplicationList() {
		ArrayList<DonationBean> supportGroupApplicationList = new ArrayList<DonationBean>();
		try {
			sql = "select group_no, campaign_list_no, campaign_list_group, b.donation_money"; 
			sql += " from (select group_no, campaign_list_no, campaign_list_group";
			sql += " from campaign_list_tbl where group_status = 'N') a,";
			sql += " (select donation_campaign_no, comgrp_member_name, format(sum(donation_money),0) as donation_money";
			sql += " from comgrpMember_donation_tbl a,";
			sql += " (select comgrp_member_id, comgrp_member_name";
			sql += " from comgrp_member_tbl";
			sql += " where comgrp_member_category = 'G') b";
			sql += " where donation_member_id = comgrp_member_id and pay_status = 'Y'";
			sql += " group by donation_campaign_no, donation_member_id) b";
			sql += " where comgrp_member_name = campaign_list_group and campaign_list_no = donation_campaign_no";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationBean supportGroupBean = null;
			
			while (rs.next()) {
				supportGroupBean = new DonationBean();
				
				supportGroupBean.setDonation_no(rs.getInt("group_no"));
				supportGroupBean.setDonation_campaign_no(rs.getInt("campaign_list_no"));
				supportGroupBean.setDonation_member_id(rs.getString("campaign_list_group"));
				supportGroupBean.setDonation_money(rs.getString("donation_money"));
				
				supportGroupApplicationList.add(supportGroupBean);
			}
		} catch (Exception e) {
			System.out.println("getSupportGroupApplicationList 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return supportGroupApplicationList;
	}

	//관리자 보낸 지원금 내역 가져오기
	public ArrayList<CampaignHistoryBean> getGrantSendHistory(String group_name, String campaign_name) {
		ArrayList<CampaignHistoryBean> grantSendHistoryList = new ArrayList<CampaignHistoryBean>();
		try {
			sql = "select format(campaign_support_amount,0) as campaign_support_amount, campaign_support_date from campaign_history_tbl where campaign_support_group_name = '" + group_name + "' and campaign_support_campaign_name = '" + campaign_name + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			CampaignHistoryBean historyBean = null;
			
			while (rs.next()) {
				historyBean = new CampaignHistoryBean();
				
				historyBean.setCampaign_support_amount(rs.getString("campaign_support_amount"));
				historyBean.setCampaign_supprot_date(rs.getDate("campaign_support_date"));
				
				grantSendHistoryList.add(historyBean);
			}
		} catch (Exception e) {
			System.out.println("getGrantSendHistory 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return grantSendHistoryList;
	}

	//일반회원 개인 기부내역 가져오기
	public ArrayList<DonationBean> getNormalMemberDonationHistory(String id) {
		ArrayList<DonationBean> normalMemberDonationHistory = new ArrayList<DonationBean>();
		try {
			sql = "select donation_no, format(donation_money,0) as donation_money, donation_date, donation_campaign_no, (case donation_type when 'T' then '일시결제' when 'R' then '정기결제' end) as donation_type, (case pay_type when 'B' then '계좌' when 'C' then '카드' end) as pay_type, pay_status from normalMember_donation_tbl where donation_member_id = '" + id + "' order by pay_status desc, donation_type";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationBean normalMemberDonationBean = null;
			
			while (rs.next()) {
				normalMemberDonationBean = new DonationBean();
				
				normalMemberDonationBean.setDonation_no(rs.getInt("donation_no"));
				normalMemberDonationBean.setDonation_money(rs.getString("donation_money"));
				normalMemberDonationBean.setDonation_date(rs.getDate("donation_date"));
				normalMemberDonationBean.setDonation_campaign_no(rs.getInt("donation_campaign_no"));
				normalMemberDonationBean.setDonation_type(rs.getString("donation_type"));
				normalMemberDonationBean.setPay_type(rs.getString("pay_type"));
				normalMemberDonationBean.setPay_status(rs.getString("pay_status"));
				
				normalMemberDonationHistory.add(normalMemberDonationBean);
			}
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationHistory 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return normalMemberDonationHistory;
	}

	//기업/단체회원 개인 기부내역 가져오기
	public ArrayList<DonationBean> getComgrpMemberDonationHistory(String id) {
		ArrayList<DonationBean> comgrpMemberDonationHistory = new ArrayList<DonationBean>();
		try {
			sql = "select donation_no, format(donation_money,0) as donation_money, donation_date, donation_campaign_no, (case donation_type when 'T' then '일시결제' when 'R' then '정기결제' end) as donation_type, (case pay_type when 'B' then '계좌' when 'C' then '카드' end) as pay_type, pay_status from comgrpMember_donation_tbl where donation_member_id = '" + id + "' order by pay_status desc, donation_type";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationBean comgrpMemberDonationBean = null;
			
			while (rs.next()) {
				comgrpMemberDonationBean = new DonationBean();
				
				comgrpMemberDonationBean.setDonation_no(rs.getInt("donation_no"));
				comgrpMemberDonationBean.setDonation_money(rs.getString("donation_money"));
				comgrpMemberDonationBean.setDonation_date(rs.getDate("donation_date"));
				comgrpMemberDonationBean.setDonation_campaign_no(rs.getInt("donation_campaign_no"));
				comgrpMemberDonationBean.setDonation_type(rs.getString("donation_type"));
				comgrpMemberDonationBean.setPay_type(rs.getString("pay_type"));
				comgrpMemberDonationBean.setPay_status(rs.getString("pay_status"));
				
				comgrpMemberDonationHistory.add(comgrpMemberDonationBean);
			}
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationHistory 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return comgrpMemberDonationHistory;
	}

	//회원의 총 기부금 가져오기
	public int getAllDonationMoney(String member_id, String member_category) {
		int allDonationMoney = 0;
		try {
			if (member_category.equalsIgnoreCase("normal")) {
				sql = "select sum(cast(donation_money as unsigned)) as donation_money from normalMember_donation_tbl where donation_member_id = '" + member_id + "' and pay_status = 'Y' group by donation_member_id";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
					allDonationMoney = Integer.parseInt(rs.getString("donation_money"));
				}
			} else if (member_category.equalsIgnoreCase("comgrp")) {
				sql = "select sum(cast(donation_money as unsigned)) as donation_money from comgrpMember_donation_tbl where donation_member_id = '" + member_id + "' and pay_status = 'Y' group by donation_member_id";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
					allDonationMoney = Integer.parseInt(rs.getString("donation_money"));
				}
			}
		} catch (Exception e) {
			System.out.println("getAllDonationMoney 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return allDonationMoney;
	}

	//회원 등급 가져오기
	public String getGrade(String member_id, String member_category) {
		String grade = "";
		try {
			if (member_category.equalsIgnoreCase("normal")) {
				sql = "select normal_member_grade from normal_member_tbl where normal_member_id = '" + member_id + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
					grade = rs.getString("normal_member_grade");
				}
			} else if (member_category.equalsIgnoreCase("comgrp")) {
				sql = "select comgrp_member_grade from comgrp_member_tbl where comgrp_member_id = '" + member_id + "'";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
					grade = rs.getString("comgrp_member_grade");
				}
			}
		} catch (Exception e) {
			System.out.println("getGrade 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return grade;
	}

	//회원 총 후원금 100만원 이상 B등급 업데이트
	public int gradeBUpdate(String member_id, String member_category) {
		int updateCount = 0;
		try {
			if (member_category.equalsIgnoreCase("normal")) {
				sql = "update normal_member_tbl set normal_member_grade = 'B' where normal_member_id = '" + member_id + "'";
				pstmt = con.prepareStatement(sql);
				
				updateCount = pstmt.executeUpdate();
			} else if (member_category.equalsIgnoreCase("comgrp")) {
				sql = "update comgrp_member_tbl set comgrp_member_grade = 'B' where comgrp_member_id = '" + member_id + "'";
				pstmt = con.prepareStatement(sql);
				
				updateCount = pstmt.executeUpdate();
			}
		} catch (Exception e) {
			System.out.println("gradeBUpdate 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return updateCount;
	}

	//회원 총 후원금 1000만원 이상 A-등급 업데이트
	public int gradeAMinusUpdate(String member_id, String member_category) {
		int updateCount = 0;
		try {
			if (member_category.equalsIgnoreCase("normal")) {
				sql = "update normal_member_tbl set normal_member_grade = 'A-' where normal_member_id = '" + member_id + "'";
				pstmt = con.prepareStatement(sql);
				
				updateCount = pstmt.executeUpdate();
			} else if (member_category.equalsIgnoreCase("comgrp")) {
				sql = "update comgrp_member_tbl set comgrp_member_grade = 'A-' where comgrp_member_id = '" + member_id + "'";
				pstmt = con.prepareStatement(sql);
				
				updateCount = pstmt.executeUpdate();
			}
		} catch (Exception e) {
			System.out.println("gradeAMinusUpdate 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return updateCount;
	}

	//회원 총 후원금 1억원 이상 A등급 업데이트
	public int gradeAUpdate(String member_id, String member_category) {
		int updateCount = 0;
		try {
			if (member_category.equalsIgnoreCase("normal")) {
				sql = "update normal_member_tbl set normal_member_grade = 'A' where normal_member_id = '" + member_id + "'";
				pstmt = con.prepareStatement(sql);
				
				updateCount = pstmt.executeUpdate();
			} else if (member_category.equalsIgnoreCase("comgrp")) {
				sql = "update comgrp_member_tbl set comgrp_member_grade = 'A' where comgrp_member_id = '" + member_id + "'";
				pstmt = con.prepareStatement(sql);
				
				updateCount = pstmt.executeUpdate();
			}
		} catch (Exception e) {
			System.out.println("gradeAUpdate 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return updateCount;
	}

	//일반회원 기부내역 카드정보 가져오기
	public ArrayList<DonationCardBean> getNormalMemberDonationCardInfo() {
		ArrayList<DonationCardBean> normalMemberDonationCardInfo = new ArrayList<DonationCardBean>();
		try {
			sql = "select donation_no, pay_date, card_name, card_proprietor, (case card_category when 'personal' then '개인' when 'corporation' then '법인' end) as card_category from normalMember_donation_cardInfo_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationCardBean normalDonationCardInfoBean = null;
			
			while (rs.next()) {
				normalDonationCardInfoBean = new DonationCardBean();
				
				normalDonationCardInfoBean.setCard_proprietor(rs.getString("card_proprietor"));
				normalDonationCardInfoBean.setPay_date(rs.getString("pay_date"));
				normalDonationCardInfoBean.setDonation_no(rs.getInt("donation_no"));
				normalDonationCardInfoBean.setCard_category(rs.getString("card_category"));
				normalDonationCardInfoBean.setCard_name(rs.getString("card_name"));
				
				normalMemberDonationCardInfo.add(normalDonationCardInfoBean);
			}
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationCardInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return normalMemberDonationCardInfo;
	}

	//기업/단체회원 기부내역 카드정보 가져오기
	public ArrayList<DonationCardBean> getComgrpMemberDonationCardInfo() {
		ArrayList<DonationCardBean> comgrpMemberDonationCardInfo = new ArrayList<DonationCardBean>();
		try {
			sql = "select donation_no, pay_date, card_name, card_proprietor, (case card_category when 'personal' then '개인' when 'corporation' then '법인' end) as card_category from comgrpMember_donation_cardInfo_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationCardBean comgrpDonationCardInfoBean = null;
			
			while (rs.next()) {
				comgrpDonationCardInfoBean = new DonationCardBean();
				
				comgrpDonationCardInfoBean.setCard_proprietor(rs.getString("card_proprietor"));
				comgrpDonationCardInfoBean.setPay_date(rs.getString("pay_date"));
				comgrpDonationCardInfoBean.setDonation_no(rs.getInt("donation_no"));
				comgrpDonationCardInfoBean.setCard_category(rs.getString("card_category"));
				comgrpDonationCardInfoBean.setCard_name(rs.getString("card_name"));
				
				comgrpMemberDonationCardInfo.add(comgrpDonationCardInfoBean);
			}
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationCardInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return comgrpMemberDonationCardInfo;
	}

	//일반회원 기부내역 계좌정보 가져오기
	public ArrayList<DonationBankBean> getNormalMemberDonationBankInfo() {
		ArrayList<DonationBankBean> normalMemberDonationBankInfo = new ArrayList<DonationBankBean>();
		try {
			sql = "select donation_no, pay_date, bank_name, bank_proprietor, (case bank_category when 'personal' then '개인' when 'corporation' then '법인' end) as bank_category from normalMember_donation_bankInfo_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationBankBean normalDonationBankInfoBean = null;
			
			while (rs.next()) {
				normalDonationBankInfoBean = new DonationBankBean();
				
				normalDonationBankInfoBean.setBank_proprietor(rs.getString("bank_proprietor"));
				normalDonationBankInfoBean.setPay_date(rs.getString("pay_date"));
				normalDonationBankInfoBean.setDonation_no(rs.getInt("donation_no"));
				normalDonationBankInfoBean.setBank_category(rs.getString("bank_category"));
				normalDonationBankInfoBean.setBank_name(rs.getString("bank_name"));
				
				normalMemberDonationBankInfo.add(normalDonationBankInfoBean);
			}
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationBankInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return normalMemberDonationBankInfo;
	}

	//기업/단체회원 기부내역 계좌정보 가져오기
	public ArrayList<DonationBankBean> getComgrpMemberDonationBankInfo() {
		ArrayList<DonationBankBean> comgrpMemberDonationBankInfo = new ArrayList<DonationBankBean>();
		try {
			sql = "select donation_no, pay_date, bank_name, bank_proprietor, (case bank_category when 'personal' then '개인' when 'corporation' then '법인' end) as bank_category from comgrpMember_donation_bankInfo_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationBankBean comgrpDonationBankInfoBean = null;
			
			while (rs.next()) {
				comgrpDonationBankInfoBean = new DonationBankBean();
				
				comgrpDonationBankInfoBean.setBank_proprietor(rs.getString("bank_proprietor"));
				comgrpDonationBankInfoBean.setPay_date(rs.getString("pay_date"));
				comgrpDonationBankInfoBean.setDonation_no(rs.getInt("donation_no"));
				comgrpDonationBankInfoBean.setBank_category(rs.getString("bank_category"));
				comgrpDonationBankInfoBean.setBank_name(rs.getString("bank_name"));
				
				comgrpMemberDonationBankInfo.add(comgrpDonationBankInfoBean);
			}
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationBankInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return comgrpMemberDonationBankInfo;
	}

	//일반회원 통장 승인 전 기부내역 가져오기
	public ArrayList<DonationBean> getNormalMemberDonationHistory() {
		ArrayList<DonationBean> normalMemberDonationHistory = new ArrayList<DonationBean>();
		try {
			sql = "select donation_campaign_no, donation_member_id, format(sum(donation_money),0) as donation_money from normalMember_donation_tbl where pay_status = 'N' group by donation_member_id, donation_campaign_no";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationBean normalDonationInfoBean = null;
			
			while (rs.next()) {
				normalDonationInfoBean = new DonationBean();
				
				normalDonationInfoBean.setDonation_campaign_no(rs.getInt("donation_campaign_no"));
				normalDonationInfoBean.setDonation_member_id(rs.getString("donation_member_id"));
				normalDonationInfoBean.setDonation_money(rs.getString("donation_money"));
				
				normalMemberDonationHistory.add(normalDonationInfoBean);
			}
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationHistory 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return normalMemberDonationHistory;
	}

	//기업/단체회원 통장 승인 전 기부내역 가져오기
	public ArrayList<DonationBean> getComgrpMemberDonationHistory() {
		ArrayList<DonationBean> comgrpMemberDonationHistory = new ArrayList<DonationBean>();
		try {
			sql = "select donation_campaign_no, donation_member_id, format(sum(donation_money),0) as donation_money from comgrpMember_donation_tbl where pay_status = 'N' group by donation_member_id, donation_campaign_no";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			DonationBean comgrpDonationInfoBean = null;
			
			while (rs.next()) {
				comgrpDonationInfoBean = new DonationBean();
				
				comgrpDonationInfoBean.setDonation_campaign_no(rs.getInt("donation_campaign_no"));
				comgrpDonationInfoBean.setDonation_member_id(rs.getString("donation_member_id"));
				comgrpDonationInfoBean.setDonation_money(rs.getString("donation_money"));
				
				comgrpMemberDonationHistory.add(comgrpDonationInfoBean);
			}
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationHistory 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return comgrpMemberDonationHistory;
	}
	
}
