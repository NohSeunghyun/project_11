/*
 * DB 관련 공통 기능 클래스
 */
package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class JdbcUtil {
	public static Connection getConnection() {
		Connection con = null;
		
		try {
			Context ititCtX = new InitialContext();
			Context envCtx = (Context)ititCtX.lookup("java:comp/env");
			DataSource ds = (DataSource)envCtx.lookup("jdbc/MySQLDB");
			con = ds.getConnection();
			con.setAutoCommit(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	/*
	 * Connection객체를 닫아주는 메서드
	 */
	public static void close(Connection con) {
		try {
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Statement객체를 닫아주는 메서드
	 */
	public static void close(Statement st) {
		try {
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * PreparedStatement객체를 닫아주는 메서드
	 */
	public static void close(PreparedStatement ps) {
		try {
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * ResultSet객체를 닫아주는 메서드
	 */
	public static void close(ResultSet rs) {
		try {
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*-------------------------------------*/
	
	/*
	 * 트랜젝션 중에 실행된 작업들을 '완료'시키는 메서드
	 */
	public static void commit(Connection con) {
		try {
			con.commit();
			System.out.println("commit success");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * 트랜젝션 중에 실행된 작업들을 '취소'시키는 메서드
	 */
	public static void rollback(Connection con) {
		try {
			con.rollback();
			System.out.println("rollback success");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
