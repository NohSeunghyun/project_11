package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;
import vo.login.NormalMemberBean;

public class JoinMembership_NormalProService {

	//일반회원 회원가입 Service
	public boolean joinMemberShip(NormalMemberBean normalMember) throws Exception {
		boolean isJoinMemberShipSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			int joinMemberShipCount = loginDAO.joinMemberShip_normal(normalMember);
		
			if (joinMemberShipCount > 0) {
				commit(con);
				isJoinMemberShipSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("joinMemberShipNormalService 에러" + e);
		} finally {
			close(con);
		}
		return isJoinMemberShipSuccess;
	}
}
