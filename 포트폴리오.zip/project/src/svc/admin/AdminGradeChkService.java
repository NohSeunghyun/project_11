package svc.admin;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.AdminDAO;

public class AdminGradeChkService {

	//관리자 등급 체크 Service
	public String isAdminGrade(String admin_id) {
		String admin_grade = "";
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
		
			admin_grade = adminDAO.isAdminGrade(admin_id);
		} catch (Exception e) {
			System.out.println("isAdminGradeService 에러" + e);
		} finally {
			close(con);
		}
		return admin_grade;
	}

}
