package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.DonationDAO;
import vo.donation.DonationBankBean;
import vo.donation.DonationBean;
import vo.donation.DonationCardBean;

public class DonationService {

	//일반회원 카드 기부 처리 Service
	public boolean donationCardNormalMember(DonationBean donationInfo) {
		boolean donationSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int donationCount = donationDAO.donationCardNormalMember(donationInfo);
		
			if (donationCount > 0) {
				commit(con);
				donationSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationCardNormalMemberService 에러" + e);
		} finally {
			close(con);
		}
		return donationSuccess;
	}

	//기업/단체회원 카드 기부 처리 Service
	public boolean donationCardComgrpMember(DonationBean donationInfo) {
		boolean donationSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int donationCount = donationDAO.donationCardComgrpMember(donationInfo);
		
			if (donationCount > 0) {
				commit(con);
				donationSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationCardComgrpMemberService 에러" + e);
		} finally {
			close(con);
		}
		return donationSuccess;
	}

	//일반회원 계좌 기부 처리 Service
	public boolean donationBankNormalMember(DonationBean donationInfo) {
		boolean donationSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int donationCount = donationDAO.donationBankNormalMember(donationInfo);
		
			if (donationCount > 0) {
				commit(con);
				donationSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationBankNormalMemberService 에러" + e);
		} finally {
			close(con);
		}
		return donationSuccess;
	}

	//기업/단체회원 계좌 기부 처리 Service
	public boolean donationBankComgrpMember(DonationBean donationInfo) {
		boolean donationSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int donationCount = donationDAO.donationBankComgrpMember(donationInfo);
		
			if (donationCount > 0) {
				commit(con);
				donationSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationBankComgrpMemberService 에러" + e);
		} finally {
			close(con);
		}
		return donationSuccess;
	}

	//일반회원 카드 일시결제 정보 Insert Service
	public boolean donationNormalMemberTemporaryCardInfoInsert(DonationCardBean cardInfo) {
		boolean donationCardInfoInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int cardInfoInsertCount = donationDAO.donationNormalMemberTemporaryCardInfoInsert(cardInfo);
		
			if (cardInfoInsertCount > 0) {
				commit(con);
				donationCardInfoInsertSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationNormalMemberTemporaryCardInfoInsertService 에러" + e);
		} finally {
			close(con);
		}
		return donationCardInfoInsertSuccess;
	}

	//일반회원 카드 정기결제 정보 Insert Service
	public boolean donationNormalMemberRegularlyCardInfoInsert(DonationCardBean cardInfo) {
		boolean donationCardInfoInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int cardInfoInsertCount = donationDAO.donationNormalMemberRegularlyCardInfoInsert(cardInfo);
		
			if (cardInfoInsertCount > 0) {
				commit(con);
				donationCardInfoInsertSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationNormalMemberRegularlyCardInfoInsertService 에러" + e);
		} finally {
			close(con);
		}
		return donationCardInfoInsertSuccess;
	}

	//기업/단체회원 카드 일시결제 정보 Insert Service
	public boolean donationComgrpMemberTemporaryCardInfoInsert(DonationCardBean cardInfo) {
		boolean donationCardInfoInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int cardInfoInsertCount = donationDAO.donationComgrpMemberTemporaryCardInfoInsert(cardInfo);
		
			if (cardInfoInsertCount > 0) {
				commit(con);
				donationCardInfoInsertSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationComgrpMemberTemporaryCardInfoInsertService 에러" + e);
		} finally {
			close(con);
		}
		return donationCardInfoInsertSuccess;
	}

	//기업/단체회원 카드 정기결제 정보 Insert Service
	public boolean donationComgrpMemberRegularlyCardInfoInsert(DonationCardBean cardInfo) {
		boolean donationCardInfoInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int cardInfoInsertCount = donationDAO.donationComgrpMemberRegularlyCardInfoInsert(cardInfo);
		
			if (cardInfoInsertCount > 0) {
				commit(con);
				donationCardInfoInsertSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationComgrpMemberRegularlyCardInfoInsertService 에러" + e);
		} finally {
			close(con);
		}
		return donationCardInfoInsertSuccess;
	}

	//일반회원 계좌 일시결제 정보 Insert Service
	public boolean donationNormalMemberTemporaryBankInfoInsert(DonationBankBean bankInfo) {
		boolean donationBankInfoInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int bankInfoInsertCount = donationDAO.donationNormalMemberTemporaryBankInfoInsert(bankInfo);
		
			if (bankInfoInsertCount > 0) {
				commit(con);
				donationBankInfoInsertSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationNormalMemberTemporaryBankInfoInsertService 에러" + e);
		} finally {
			close(con);
		}
		return donationBankInfoInsertSuccess;
	}
	
	//일반회원 계좌 정기결제 정보 Insert Service
	public boolean donationNormalMemberRegularlyBankInfoInsert(DonationBankBean bankInfo) {
		boolean donationBankInfoInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int bankInfoInsertCount = donationDAO.donationNormalMemberRegularlyBankInfoInsert(bankInfo);
		
			if (bankInfoInsertCount > 0) {
				commit(con);
				donationBankInfoInsertSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationNormalMemberRegularlyBankInfoInsertService 에러" + e);
		} finally {
			close(con);
		}
		return donationBankInfoInsertSuccess;
	}

	//기업/단체회원 계좌 일시결제 정보 Insert Service
	public boolean donationComgrpMemberTemporaryBankInfoInsert(DonationBankBean bankInfo) {
		boolean donationBankInfoInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int bankInfoInsertCount = donationDAO.donationComgrpMemberTemporaryBankInfoInsert(bankInfo);
		
			if (bankInfoInsertCount > 0) {
				commit(con);
				donationBankInfoInsertSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationComgrpMemberTemporaryBankInfoInsertService 에러" + e);
		} finally {
			close(con);
		}
		return donationBankInfoInsertSuccess;
	}

	//기업/단체회원 계좌 정기결제 정보 Insert Service
	public boolean donationComgrpMemberRegularlyBankInfoInsert(DonationBankBean bankInfo) {
		boolean donationBankInfoInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int bankInfoInsertCount = donationDAO.donationComgrpMemberRegularlyBankInfoInsert(bankInfo);
		
			if (bankInfoInsertCount > 0) {
				commit(con);
				donationBankInfoInsertSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("donationComgrpMemberRegularlyBankInfoInsertService 에러" + e);
		} finally {
			close(con);
		}
		return donationBankInfoInsertSuccess;
	}
	
}
