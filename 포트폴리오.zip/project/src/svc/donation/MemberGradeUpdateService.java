package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.DonationDAO;

public class MemberGradeUpdateService {

	//회원 총 후원금 100만원 이상 B등급 업데이트 Service
	public boolean gradeBUpdate(String member_id, String member_category) {
		boolean memberGradeUpdateSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int updateCount = donationDAO.gradeBUpdate(member_id, member_category);
			
			if (updateCount > 0) {
				commit(con);
				memberGradeUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("gradeBUpdateService 에러" + e);
		} finally {
			close(con);
		}
		return memberGradeUpdateSuccess;
	}

	//회원 총 후원금 1000만원 이상 A-등급 업데이트 Service
	public boolean gradeAMinusUpdate(String member_id, String member_category) {
		boolean memberGradeUpdateSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int updateCount = donationDAO.gradeAMinusUpdate(member_id, member_category);
			
			if (updateCount > 0) {
				commit(con);
				memberGradeUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("gradeAMinusUpdateService 에러" + e);
		} finally {
			close(con);
		}
		return memberGradeUpdateSuccess;
	}

	//회원 총 후원금 1억원 이상 A등급 업데이트 Service
	public boolean gradeAUpdate(String member_id, String member_category) {
		boolean memberGradeUpdateSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			int updateCount = donationDAO.gradeAUpdate(member_id, member_category);
			
			if (updateCount > 0) {
				commit(con);
				memberGradeUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("gradeAUpdateService 에러" + e);
		} finally {
			close(con);
		}
		return memberGradeUpdateSuccess;
	}

}
