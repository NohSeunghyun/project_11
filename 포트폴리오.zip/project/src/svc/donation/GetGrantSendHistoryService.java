package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.DonationDAO;
import vo.campaign.CampaignHistoryBean;

public class GetGrantSendHistoryService {

	//관리자 보낸 지원금 내역 가져오기 Service
	public ArrayList<CampaignHistoryBean> getGrantSendHistory(String group_name, String campaign_name) {
		ArrayList<CampaignHistoryBean> grantSendHistoryList = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			grantSendHistoryList = donationDAO.getGrantSendHistory(group_name, campaign_name);
		} catch (Exception e) {
			System.out.println("getGrantSendHistoryService 에러" + e);
		} finally {
			close(con);
		}
		return grantSendHistoryList;
	}

}
