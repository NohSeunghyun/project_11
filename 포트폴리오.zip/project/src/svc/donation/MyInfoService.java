package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.DonationDAO;

public class MyInfoService {

	//회원의 총 기부금 가져오기 Service
	public int getAllDonationMoney(String member_id, String member_category) {
		int allDonationMoney = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			allDonationMoney = donationDAO.getAllDonationMoney(member_id, member_category);
		} catch (Exception e) {
			System.out.println("getAllDonationMoneyService 에러" + e);
		} finally {
			close(con);
		}
		return allDonationMoney;
	}

	//회원 등급 가져오기 Service
	public String getGrade(String member_id, String member_category) {
		String grade = "";
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			grade = donationDAO.getGrade(member_id, member_category);
		} catch (Exception e) {
			System.out.println("getGradeService 에러" + e);
		} finally {
			close(con);
		}
		return grade;
	}

}
