package svc.donation;

import static db.JdbcUtil.*;
import static db.JdbcUtil.getConnection;

import java.sql.Connection;
import java.util.ArrayList;

import dao.DonationDAO;
import vo.donation.DonationBankBean;

public class DonationBankInfoService {

	//일반회원 기부내역 계좌정보 가져오기 Service
	public ArrayList<DonationBankBean> getNormalMemberDonationBankInfo() {
		ArrayList<DonationBankBean> normalMemberDonationBankInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			normalMemberDonationBankInfo = donationDAO.getNormalMemberDonationBankInfo();
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationBankInfoService 에러" + e);
		} finally {
			close(con);
		}
		return normalMemberDonationBankInfo;
	}
	
	//기업/단체회원 기부내역 계좌정보 가져오기 Service
	public ArrayList<DonationBankBean> getComgrpMemberDonationBankInfo() {
		ArrayList<DonationBankBean> comgrpMemberDonationBankInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			comgrpMemberDonationBankInfo = donationDAO.getComgrpMemberDonationBankInfo();
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationBankInfoService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpMemberDonationBankInfo;
	}

}
