package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.DonationDAO;
import vo.donation.DonationBean;

public class DonationHistoryService {

	//일반회원 개인 기부내역 가져오기 Service
	public ArrayList<DonationBean> normalMemberDonationHistory(String id) {
		ArrayList<DonationBean> normalMemberDonationHistory = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			normalMemberDonationHistory = donationDAO.getNormalMemberDonationHistory(id);
		} catch (Exception e) {
			System.out.println("normalMemberDonationHistoryService 에러" + e);
		} finally {
			close(con);
		}
		return normalMemberDonationHistory;
	}

	//기업/단체회원 개인 기부내역 가져오기 Service
	public ArrayList<DonationBean> comgrpMemberDonationHistory(String id) {
		ArrayList<DonationBean> comgrpMemberDonationHistory = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			comgrpMemberDonationHistory = donationDAO.getComgrpMemberDonationHistory(id);
		} catch (Exception e) {
			System.out.println("comgrpMemberDonationHistoryService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpMemberDonationHistory;
	}

	//일반회원 통장 승인 전 기부내역 가져오기 Service
	public ArrayList<DonationBean> normalMemberDonationHistory() {
		ArrayList<DonationBean> normalMemberDonationHistory = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			normalMemberDonationHistory = donationDAO.getNormalMemberDonationHistory();
		} catch (Exception e) {
			System.out.println("normalMemberDonationHistoryService 에러" + e);
		} finally {
			close(con);
		}
		return normalMemberDonationHistory;
	}

	//기업/단체회원 통장 승인 전 기부내역 가져오기 Service
	public ArrayList<DonationBean> comgrpMemberDonationHistory() {
		ArrayList<DonationBean> comgrpMemberDonationHistory = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			comgrpMemberDonationHistory = donationDAO.getComgrpMemberDonationHistory();
		} catch (Exception e) {
			System.out.println("comgrpMemberDonationHistoryService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpMemberDonationHistory;
	}
	
}
