package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.DonationDAO;
import vo.donation.DonationCardBean;

public class DonationCardInfoService {

	//일반회원 개인 기부내역 카드정보 가져오기 Service
	public ArrayList<DonationCardBean> getNormalMemberDonationCardInfo() {
		ArrayList<DonationCardBean> normalMemberDonationCardInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			normalMemberDonationCardInfo = donationDAO.getNormalMemberDonationCardInfo();
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationCardInfoService 에러" + e);
		} finally {
			close(con);
		}
		return normalMemberDonationCardInfo;
	}

	//기업/단체회원 개인 기부내역 카드정보 가져오기 Service
	public ArrayList<DonationCardBean> getComgrpMemberDonationCardInfo() {
		ArrayList<DonationCardBean> comgrpMemberDonationCardInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			comgrpMemberDonationCardInfo = donationDAO.getComgrpMemberDonationCardInfo();
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationCardInfoService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpMemberDonationCardInfo;
	}

}
