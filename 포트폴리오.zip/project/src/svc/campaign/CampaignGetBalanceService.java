package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;

public class CampaignGetBalanceService {

	//지원금 전송 전 캠페인 후원금 잔액 확인 Service
	public long getBalance(int campaign_no) {
		long balance = 0;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
		
			balance = campaignDAO.getBalance(campaign_no);
		} catch (Exception e) {
			System.out.println("getBalanceService 에러" + e);
		} finally {
			close(con);
		}
		return balance;
	}

	//잔액 콤마찍기 Service
	public String getBalanceFormat(int campaign_no) {
		String balance = "";
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
		
			balance = campaignDAO.getBalanceFormat(campaign_no);
		} catch (Exception e) {
			System.out.println("getBalanceFormatService 에러" + e);
		} finally {
			close(con);
		}
		return balance;
	}

}
