package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.CampaignDAO;
import vo.campaign.CampaignBean;
import vo.campaign.CampaignListBean;

public class CampaignListService {

	//모든 캠페인 조회 Service
	public ArrayList<CampaignBean> getCampaign() {
		ArrayList<CampaignBean> campaignList = null;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			campaignList = campaignDAO.getCampaign();
		} catch (Exception e) {
			System.out.println("getCampaignService 에러" + e);
		} finally {
			close(con);
		}
		return campaignList;
	}

	//캠페인 지원 단체 목록 조회 Service
	public ArrayList<CampaignListBean> getCampaignDetailList(int campaign_no) {
		ArrayList<CampaignListBean> campaignDetailList = null;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			campaignDetailList = campaignDAO.getCampaignDetailList(campaign_no);
		} catch (Exception e) {
			System.out.println("getCampaignDetailListService 에러" + e);
		} finally {
			close(con);
		}
		return campaignDetailList;
	}

	//모든 캠페인 지원 단체 목록 조회 Service
	public ArrayList<CampaignListBean> getSupportGroup() {
		ArrayList<CampaignListBean> supportGroupList = null;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			supportGroupList = campaignDAO.getSupportGroup();
		} catch (Exception e) {
			System.out.println("getSupportGroupService 에러" + e);
		} finally {
			close(con);
		}
		return supportGroupList;
	}

	//지원단체 신청 전 중복 확인 Service
	public boolean supportGroupOverlapChk(String campaign_no, String group_name) {
		boolean suppotGroupOverlapChk = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			suppotGroupOverlapChk = campaignDAO.supportGroupOverlapChk(campaign_no, group_name);
		} catch (Exception e) {
			System.out.println("supportGroupOverlapChkService 에러" + e);
		} finally {
			close(con);
		}
		return suppotGroupOverlapChk;
	}

}
