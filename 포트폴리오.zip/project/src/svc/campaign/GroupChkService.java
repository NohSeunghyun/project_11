package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;

public class GroupChkService {

	//기업/단체회원 구분 Service
	public String getComgrpCategory(String id) {
		String member_groupChk = "";
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			member_groupChk = campaignDAO.getComgrpCategory(id);
		} catch (Exception e) {
			System.out.println("getComgrpCategoryService 에러" + e);
		} finally {
			close(con);
		}
		return member_groupChk;
	}

}
