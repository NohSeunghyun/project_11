package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;

public class GrantSendService {

	//지원금 전송 후 캠페인 잔액, 보낸 지원금 수정 Service
	public boolean grantSendCampaignInfoUpdate(int campaign_no, long amount) {
		boolean isCampaignInfoUpdateSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int updateCount = campaignDAO.grantSendCampaignInfoUpdate(campaign_no, amount);
			
			if (updateCount > 0) {
				commit(con);
				isCampaignInfoUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("grantSendCampaignInfoUpdateService 에러" + e);
		} finally {
			close(con);
		}
		return isCampaignInfoUpdateSuccess;
	}

	//지원금 전송 후 지원단체 지원금 수정 Service
	public boolean grantSendSupportGroupInfoUpdate(int group_no, long amount) {
		boolean isSupportGroupInfoUpdateSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int updateCount = campaignDAO.grantSendSupportGroupInfoUpdate(group_no, amount);
			
			if (updateCount > 0) {
				commit(con);
				isSupportGroupInfoUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("grantSendSupportGroupInfoUpdateService 에러" + e);
		} finally {
			close(con);
		}
		return isSupportGroupInfoUpdateSuccess;
	}

	//지원금 내역에 넣을 캠페인명 가져오기 Service
	public String getCampaignName(int campaign_no) {
		String campaign_name = "";
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			campaign_name = campaignDAO.getCampaignName(campaign_no);
		} catch (Exception e) {
			System.out.println("getCampaignNameService 에러" + e);
		} finally {
			close(con);
		}
		return campaign_name;
	}

	//지원금 내역 추가 Service
	public boolean grantSendHistoryInsert(String campaign_name, long amount, String group_name) {
		boolean isGrantSendHistoryInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int insertCount = campaignDAO.grantSendHistoryInsert(campaign_name, amount, group_name);
			
			if (insertCount > 0) {
				commit(con);
				isGrantSendHistoryInsertSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("grantSendHistoryInsertService 에러" + e);
		} finally {
			close(con);
		}
		return isGrantSendHistoryInsertSuccess;
	}

}
