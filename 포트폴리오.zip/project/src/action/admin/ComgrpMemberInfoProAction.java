package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.admin.MemberInformationService;
import vo.ActionForward;
import vo.login.CompanyGroupMemberBean;

public class ComgrpMemberInfoProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		String id = request.getParameter("member_id");
		
		MemberInformationService memberInformationService = new MemberInformationService();
		CompanyGroupMemberBean comgrpInfo = memberInformationService.adminComgrpMemberInfo(id);
		
		if (comgrpInfo == null) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('정보조회에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			request.setAttribute("comgrpInfo", comgrpInfo);
			forward = new ActionForward("comgrpMemberChangeInfoForm.page", false);
		}
		return forward;
	}

}
