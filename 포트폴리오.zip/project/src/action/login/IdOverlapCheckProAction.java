package action.login;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.IdOverlapCheckProService;
import vo.ActionForward;

public class IdOverlapCheckProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("userId");
		IdOverlapCheckProService idOverlapCheckProService = new IdOverlapCheckProService();
		boolean isIdOverlapChk = idOverlapCheckProService.isIdOverlapChk(id);
		
		if (isIdOverlapChk == false) {
			forward = new ActionForward("idOverlapCheckSuccessForm.page", false);
		} else {
			out.println("<script>");
			out.println("alert('이 아이디를 사용하실 수 없습니다.');");
			out.println("self.close();");
			out.println("</script>");
		}
		
		request.setAttribute("Id", id);
		return forward;
	}

}
