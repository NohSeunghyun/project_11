package action.login;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.login.LoginProService;
import vo.ActionForward;

public class LoginProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("member_id");
		String pw = request.getParameter("member_pw");
		String name = "";
		boolean loginSuccess = false;
		
		LoginProService loginProService = new LoginProService();
		String isIdChk = loginProService.isIdChk(id);
		switch (isIdChk) {
			case "normal" : {
				String isPwChk = loginProService.isPwChk(id, isIdChk, pw);
				if(isPwChk != "Success") {
					out.println("<script>");
					out.println("alert('비밀번호가 일치하지 않습니다.');");
					out.println("history.back();");
					out.println("</script>");
				} else {
					loginSuccess = true;
					name = loginProService.name(id);
					forward = new ActionForward("memberLogin.page", false);
				}
				break;
			}
			case "comgrp" : {
				String isPwChk = loginProService.isPwChk(id, isIdChk, pw);
				if(isPwChk != "Success") {
					out.println("<script>");
					out.println("alert('비밀번호가 일치하지 않습니다.');");
					out.println("history.back();");
					out.println("</script>");
				} else {
					loginSuccess = true;
					name = loginProService.name(id);
					forward = new ActionForward("memberLogin.page", false);
				}
				break;
			}
			case "admin" : {
				String isPwChk = loginProService.isPwChk(id, isIdChk, pw);
				if(isPwChk != "Success") {
					out.println("<script>");
					out.println("alert('비밀번호가 일치하지 않습니다.');");
					out.println("history.back();");
					out.println("</script>");
				} else {
					loginSuccess = true;
					name = loginProService.name(id);
					forward = new ActionForward("adminLogin.page", false);
				}
				break;
			}
			case "null" : {
				out.println("<script>");
				out.println("alert('존재하지 않는 아이디입니다.');");
				out.println("location='loginFrom.page';");
				out.println("</script>");
			}
			break;
		}
		//로그인 성공시 세션유지
		if(loginSuccess) {
			HttpSession session = request.getSession();
			session.setAttribute("id", id);
			session.setAttribute("name", name);
		}
		return forward;
	}

}
