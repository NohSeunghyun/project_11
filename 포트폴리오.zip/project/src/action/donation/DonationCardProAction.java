package action.donation;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.donation.DonationInfoService;
import svc.donation.DonationService;
import svc.login.DeleteMemberChkService;
import vo.ActionForward;
import vo.donation.DonationCardBean;

public class DonationCardProAction implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String member_id = (String)session.getAttribute("id");
		
		DonationInfoService donationInfoService = new DonationInfoService();
		int donation_no = 0;
		
		DonationCardBean cardInfo = new DonationCardBean();
		
		String card_donation_type = request.getParameter("card_donation_type");
		String card_category = request.getParameter("card_category");
		String card_name = request.getParameter("card_name");
		String pay_date = request.getParameter("card_pay_date");
		String card_proprietor = "";
		String updateGrade = (String)request.getAttribute("updateGrade");
		
		if (card_category.equalsIgnoreCase("personal")) {
			card_proprietor = request.getParameter("card_personal_proprietor");
		} else if (card_category.equalsIgnoreCase("corporation")) {
			card_proprietor = request.getParameter("card_corporation_proprietor");
		}
		
		DeleteMemberChkService memberChkService = new DeleteMemberChkService();
		String member_category = memberChkService.isDeleteMemberCategory(member_id);
		
		if (member_category.equalsIgnoreCase("normal")) {
			donation_no = donationInfoService.getNormalMemberDonationNo();
			
			if (card_donation_type.equalsIgnoreCase("temporary")) {
				cardInfo.setDonation_no(donation_no);
				cardInfo.setCard_name(card_name);
				cardInfo.setCard_category(card_category);
				cardInfo.setCard_proprietor(card_proprietor);
				
				DonationService donationService = new DonationService();
				boolean donationTemporaryCardInfoInsertSuccess = donationService.donationNormalMemberTemporaryCardInfoInsert(cardInfo);
				
				if (!donationTemporaryCardInfoInsertSuccess) {
					out.println("<script>");
					out.println("alert('카드정보 업데이트에 실패하였습니다.');");
					out.println("history.back()");
					out.println("</script>");
				} else {
					if (updateGrade.equalsIgnoreCase("B")) {
						forward = new ActionForward("gradeBUpdateSuccess.page", false);
					} else if (updateGrade.equalsIgnoreCase("A-")) {
						forward = new ActionForward("gradeAMinusUpdateSuccess.page", false);
					} else if (updateGrade.equalsIgnoreCase("A")) {
						forward = new ActionForward("gradeAUpdateSuccess.page", false);
					} else if (updateGrade == "") {
						forward = new ActionForward("donationSuccess.page", false);
					}
				}
			} else if (card_donation_type.equalsIgnoreCase("regularly")) {
				cardInfo.setDonation_no(donation_no);
				cardInfo.setCard_name(card_name);
				cardInfo.setCard_category(card_category);
				cardInfo.setCard_proprietor(card_proprietor);
				cardInfo.setPay_date(pay_date);
				
				DonationService donationService = new DonationService();
				boolean donationRegularlyCardInfoInsertSuccess = donationService.donationNormalMemberRegularlyCardInfoInsert(cardInfo);
				
				if (!donationRegularlyCardInfoInsertSuccess) {
					out.println("<script>");
					out.println("alert('카드정보 업데이트에 실패하였습니다.');");
					out.println("history.back()");
					out.println("</script>");
				} else {
					if (updateGrade.equalsIgnoreCase("B")) {
						forward = new ActionForward("gradeBUpdateSuccess.page", false);
					} else if (updateGrade.equalsIgnoreCase("A-")) {
						forward = new ActionForward("gradeAMinusUpdateSuccess.page", false);
					} else if (updateGrade.equalsIgnoreCase("A")) {
						forward = new ActionForward("gradeAUpdateSuccess.page", false);
					} else if (updateGrade == "") {
						forward = new ActionForward("donationSuccess.page", false);
					}
				}
			}
		} else if (member_category.equalsIgnoreCase("comgrp")) {
			donation_no = donationInfoService.getComgrpMemberDonationNo();
			
			if (card_donation_type.equalsIgnoreCase("temporary")) {
				cardInfo.setDonation_no(donation_no);
				cardInfo.setCard_name(card_name);
				cardInfo.setCard_category(card_category);
				cardInfo.setCard_proprietor(card_proprietor);
				
				DonationService donationService = new DonationService();
				boolean donationTemporaryCardInfoInsertSuccess = donationService.donationComgrpMemberTemporaryCardInfoInsert(cardInfo);
				
				if (!donationTemporaryCardInfoInsertSuccess) {
					out.println("<script>");
					out.println("alert('카드정보 업데이트에 실패하였습니다.');");
					out.println("history.back()");
					out.println("</script>");
				} else {
					if (updateGrade.equalsIgnoreCase("B")) {
						forward = new ActionForward("gradeBUpdateSuccess.page", false);
					} else if (updateGrade.equalsIgnoreCase("A-")) {
						forward = new ActionForward("gradeAMinusUpdateSuccess.page", false);
					} else if (updateGrade.equalsIgnoreCase("A")) {
						forward = new ActionForward("gradeAUpdateSuccess.page", false);
					} else if (updateGrade == "") {
						forward = new ActionForward("donationSuccess.page", false);
					}
				}
			} else if (card_donation_type.equalsIgnoreCase("regularly")) {
				cardInfo.setDonation_no(donation_no);
				cardInfo.setCard_name(card_name);
				cardInfo.setCard_category(card_category);
				cardInfo.setCard_proprietor(card_proprietor);
				cardInfo.setPay_date(pay_date);
				
				DonationService donationService = new DonationService();
				boolean donationRegularlyCardInfoInsertSuccess = donationService.donationComgrpMemberRegularlyCardInfoInsert(cardInfo);
				
				if (!donationRegularlyCardInfoInsertSuccess) {
					out.println("<script>");
					out.println("alert('카드정보 업데이트에 실패하였습니다.');");
					out.println("history.back()");
					out.println("</script>");
				} else {
					if (updateGrade.equalsIgnoreCase("B")) {
						forward = new ActionForward("gradeBUpdateSuccess.page", false);
					} else if (updateGrade.equalsIgnoreCase("A-")) {
						forward = new ActionForward("gradeAMinusUpdateSuccess.page", false);
					} else if (updateGrade.equalsIgnoreCase("A")) {
						forward = new ActionForward("gradeAUpdateSuccess.page", false);
					} else if (updateGrade == "") {
						forward = new ActionForward("donationSuccess.page", false);
					}
				}
			}
		}
		return forward;
	}

}
