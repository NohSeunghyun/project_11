package action.donation;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.campaign.CampaignListService;
import vo.ActionForward;
import vo.campaign.CampaignBean;

public class DonationChkMemberProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String admin_id = (String)session.getAttribute("id");
		
		String campaign_no = request.getParameter("campaign_no");
		
		AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
		String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
		
		if (admin_grade != "") {
			out.println("<script>");
			out.println("alert('관리자는 기부할 수 없습니다.\\n회원으로 로그인 해주세요.');");
			out.println("history.back();");
			out.println("</script>");
		} else {
			CampaignListService campaignListService = new CampaignListService();
			ArrayList<CampaignBean> campaignList = campaignListService.getCampaign();
			
			request.setAttribute("campaignList", campaignList);
			request.setAttribute("campaign_no", campaign_no);
			forward = new ActionForward("donationForm.page", false);
		}
		return forward;
	}

}
