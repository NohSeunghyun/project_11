package action.donation;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.donation.DonationInfoService;
import svc.donation.DonationService;
import svc.login.DeleteMemberChkService;
import vo.ActionForward;
import vo.donation.DonationBankBean;

public class DonationBankProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String member_id = (String)session.getAttribute("id");
		
		DonationInfoService donationInfoService = new DonationInfoService();
		int donation_no = 0;
		
		DonationBankBean bankInfo = new DonationBankBean();
		
		String bank_donation_type = request.getParameter("bank_donation_type");
		String bank_category = request.getParameter("bank_category");
		String bank_name = request.getParameter("bank_name");
		String pay_date = request.getParameter("bank_pay_date");
		String bank_proprietor = "";
		
		if (bank_category.equalsIgnoreCase("personal")) {
			bank_proprietor = request.getParameter("bank_personal_proprietor");
		} else if (bank_category.equalsIgnoreCase("corporation")) {
			bank_proprietor = request.getParameter("bank_corporation_proprietor");
		}
		
		DeleteMemberChkService memberChkService = new DeleteMemberChkService();
		String member_category = memberChkService.isDeleteMemberCategory(member_id);
		
		if (member_category.equalsIgnoreCase("normal")) {
			donation_no = donationInfoService.getNormalMemberDonationNo();
			
			if (bank_donation_type.equalsIgnoreCase("temporary")) {
				bankInfo.setDonation_no(donation_no);
				bankInfo.setBank_category(bank_category);
				bankInfo.setBank_proprietor(bank_proprietor);
				bankInfo.setBank_name(bank_name);
				
				DonationService donationService = new DonationService();
				boolean donationTemporaryBankInfoInsertSuccess = donationService.donationNormalMemberTemporaryBankInfoInsert(bankInfo);
				
				if (!donationTemporaryBankInfoInsertSuccess) {
					out.println("<script>");
					out.println("alert('계좌정보 업데이트에 실패하였습니다.');");
					out.println("history.back()");
					out.println("</script>");
				} else {
					forward = new ActionForward("donationSuccess.page", false);
				}
			} else if (bank_donation_type.equalsIgnoreCase("regularly")) {
				bankInfo.setDonation_no(donation_no);
				bankInfo.setBank_category(bank_category);
				bankInfo.setBank_proprietor(bank_proprietor);
				bankInfo.setBank_name(bank_name);
				bankInfo.setPay_date(pay_date);
				
				DonationService donationService = new DonationService();
				boolean donationRegularlyBankInfoInsertSuccess = donationService.donationNormalMemberRegularlyBankInfoInsert(bankInfo);
				
				if (!donationRegularlyBankInfoInsertSuccess) {
					out.println("<script>");
					out.println("alert('계좌정보 업데이트에 실패하였습니다.');");
					out.println("history.back()");
					out.println("</script>");
				} else {
					forward = new ActionForward("donationSuccess.page", false);
				}
			}
		} else if (member_category.equalsIgnoreCase("comgrp")) {
			donation_no = donationInfoService.getComgrpMemberDonationNo();
			
			if (bank_donation_type.equalsIgnoreCase("temporary")) {
				bankInfo.setDonation_no(donation_no);
				bankInfo.setBank_category(bank_category);
				bankInfo.setBank_proprietor(bank_proprietor);
				bankInfo.setBank_name(bank_name);
				
				DonationService donationService = new DonationService();
				boolean donationTemporaryBankInfoInsertSuccess = donationService.donationComgrpMemberTemporaryBankInfoInsert(bankInfo);
				
				if (!donationTemporaryBankInfoInsertSuccess) {
					out.println("<script>");
					out.println("alert('계좌정보 업데이트에 실패하였습니다.');");
					out.println("history.back()");
					out.println("</script>");
				} else {
					forward = new ActionForward("donationSuccess.page", false);
				}
			} else if (bank_donation_type.equalsIgnoreCase("regularly")) {
				bankInfo.setDonation_no(donation_no);
				bankInfo.setBank_category(bank_category);
				bankInfo.setBank_proprietor(bank_proprietor);
				bankInfo.setBank_name(bank_name);
				bankInfo.setPay_date(pay_date);
				
				DonationService donationService = new DonationService();
				boolean donationRegularlyBankInfoInsertSuccess = donationService.donationComgrpMemberRegularlyBankInfoInsert(bankInfo);
				
				if (!donationRegularlyBankInfoInsertSuccess) {
					out.println("<script>");
					out.println("alert('계좌정보 업데이트에 실패하였습니다.');");
					out.println("history.back()");
					out.println("</script>");
				} else {
					forward = new ActionForward("donationSuccess.page", false);
				}
			}
		}
		return forward;
	}

}
