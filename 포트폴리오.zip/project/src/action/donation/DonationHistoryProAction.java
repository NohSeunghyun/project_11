package action.donation;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.campaign.CampaignListService;
import svc.donation.DonationInfoService;
import vo.ActionForward;
import vo.campaign.CampaignBean;
import vo.donation.DonationBean;

public class DonationHistoryProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		
		CampaignListService campaignListService = new CampaignListService();
		ArrayList<CampaignBean> campaignList = campaignListService.getCampaign();
		
		request.setAttribute("campaignList", campaignList);
		
		ArrayList<DonationBean> normalDonationInfo = null;
		ArrayList<DonationBean> comgrpDonationInfo = null;
		
		DonationInfoService donationInfoService = new DonationInfoService();
		
		normalDonationInfo = donationInfoService.getNormalMemberDonationInfo();
		comgrpDonationInfo = donationInfoService.getComgrpMemberDonationInfo();
		
		request.setAttribute("normalDonationInfo", normalDonationInfo);
		request.setAttribute("comgrpDonationInfo", comgrpDonationInfo);
		if (id != null) {
			AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
			String admin_grade = adminGradeChkService.isAdminGrade(id);
			if (admin_grade != "") {
				forward = new ActionForward("donationHistoryAdmin.page", false);
			} else {
				forward = new ActionForward("donationHistoryMember.page", false);
			}
		} else {
			forward = new ActionForward("donationHistory.page", false);
		}
		return forward;
	}

}
