package action.campaign;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.campaign.CampaignListService;
import svc.donation.DonationInfoService;
import vo.ActionForward;
import vo.campaign.CampaignBean;
import vo.donation.DonationBean;

public class SupportGroupApplicationApproveListProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		HttpSession session = request.getSession();
		String admin_id = (String)session.getAttribute("id");
		
		AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
		String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
		
		if (!admin_grade.equalsIgnoreCase("A")) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			
			out.println("<script>");
			out.println("alert('승인할 권한이 없습니다.\\nA등급만 승인 가능합니다.');");
			out.println("history.back();");
			out.println("</script>");
		} else {
			DonationInfoService donationInfoService = new DonationInfoService();
			ArrayList<DonationBean> supportGroupApplicationList = donationInfoService.getSupportGroupApplicationList();
			CampaignListService campaignListService = new CampaignListService();
			ArrayList<CampaignBean> campaignList = campaignListService.getCampaign();
			
			request.setAttribute("campaignList", campaignList);
			request.setAttribute("supportGroupApplicationList", supportGroupApplicationList);
			forward = new ActionForward("supportGroupApplicationForm.page", false);
		}
		return forward;
	}

}
